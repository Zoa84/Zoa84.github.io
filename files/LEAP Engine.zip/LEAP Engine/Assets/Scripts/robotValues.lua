jumpForce = 16000000.0
velocity = 1500.0
sprintVelocity = 2800.0